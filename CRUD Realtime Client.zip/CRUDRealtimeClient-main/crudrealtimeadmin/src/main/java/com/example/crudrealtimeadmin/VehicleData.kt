package com.example.crudrealtimeadmin

data class VehicleData(
    val ownerName: String? = null,
    val vehicleBrand: String? = null,
    val vehicleRTO: String? = null,
    val vehicleNumber: String? = null){

}